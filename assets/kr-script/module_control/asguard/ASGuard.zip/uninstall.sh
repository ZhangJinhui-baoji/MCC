#!/system/bin/sh
rm /data/media/0/Android/magisk/asguard/ASGuard.config
rm /data/media/0/Android/magisk/asguard/ASGuard.config.bak
rm /data/media/0/Android/magisk/asguard/log_ASG.txt
rm /data/media/0/Android/magisk/asguard
exit 0