MODDIR=${0%/*}
MODBIN=$MODDIR/system/bin

if [ -f "$MODDIR/flag/.need_recuser" ]; then
    rm -f $MODDIR/flag/.need_recuser
    true >$MODDIR/disable
else
    true >$MODDIR/flag/.need_recuser
fi

poll_inject() {
    true >$MODDIR/injector.log
    while true; do
        sleep 0.1
        $MODBIN/injector system_server /system/lib64/libssanalysis.so >>$MODDIR/injector.log
        [ "$?" == "0" ] && return
    done
}

(poll_inject &)
