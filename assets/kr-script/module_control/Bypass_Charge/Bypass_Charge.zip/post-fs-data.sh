MODDIR=${0%/*}
if [ "$(magisk -V)" -lt 20400 ]; then
  touch "$MODDIR/disable"
fi
