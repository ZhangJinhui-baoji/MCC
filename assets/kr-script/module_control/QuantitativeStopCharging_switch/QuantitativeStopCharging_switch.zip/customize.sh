cp "$MODPATH/module.prop" "$MODPATH/t_module"
ui_print " -------------------------- "
ui_print " ------ 安装中，请稍等 ------ "
sleep 1
ui_print " -------------------------- "
sleep 1
ui_print " -------------------------- "
sleep 1
ui_print " ----- 安装已完成，请重启 ---- "
ui_print " -------------------------- "
