MODDIR=${0%/*}
#rm rubbish
rm -rf "/data/media/0/Android/magisk/feas/feas.conf"
rm -rf "/data/media/0/Android/magisk/feas/feas.conf.bak"
rm -rf "/data/media/0/Android/magisk/feas"