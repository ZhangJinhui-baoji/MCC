SKIPUNZIP=0
MODDIR=${0%/*}
alias sh='/system/bin/sh'
echo "----------------------------------------------------"
# print FEATURES
cat "$MODPATH/FEATURES"
rm -rf "$MODPATH/FEATURES"

echo -e "\nPlease wait…"
echo "请等待…"
rm "$MODPATH/FEATURES"

# no uperf
if [ $(pidof uperf) != "" ]; then
    echo "Uperf detected, please remove."
    echo "检测到uperf，请移除"abort
fi

# remove old version
MODS_PATH="/data/adb/modules"
[ -d "$MODS_PATH/Feashelper_Mtk" ] && rm -rf "$MODS_PATH/Feashelper_Mtk"

# keep config
[ ! -f "/data/media/0/Android/magisk/feas/feas.conf" ] && cp "$MODPATH/feas.conf" "/data/media/0/Android/magisk/feas/feas.conf"
# mv /data/media/0/Android/magisk/feas/feas.conf /data/media/0/Android/magisk/feas/feas.conf.bak
# cp -f $MODPATH/feas.conf /data/media/0/Android/magisk/feas/feas.conf
# echo "Please note that this update does not preserve the configuration."

# remove model config
#rm $MODPATH/feas.conf

# permission
chmod a+x "$MODPATH/FEASHelper"

# start FEAShelper on install
killall FEASHelper > /dev/null 2>&1
echo "----------------------------------------------------"

# KSU环境屏蔽
if [[ -z $KSU ]] || [[ $KSU = false ]]; then
    $MODPATH/FEASHelper -c "/data/media/0/Android/magisk/feas/feas.conf"
    sleep 1s

    # test if FEASHelper started
    if [[ "$(pgrep FEASHelper)" == "" ]]; then
        echo "Sorry, unsupported device."
        echo "不支持的设备"
        abort
    fi
    echo "FEASHelper is running……"
    echo "FEASHelper已运行……"
fi
