#! /vendor/bin/sh

MODDIR=${0%/*}

# setprop sys.lmk.minfree_levels 12800:0,16384:100,18432:200,24576:250,32768:900,49152:950

# stop lmkd
# 
# start lmkd

swap_config="/data/swap_config.conf"
get_prop() {
  cat $swap_config | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}
lmkd=$(which lmkd)

lmkd_override() {
  sdk=$(getprop ro.build.version.sdk)
  if [[ $sdk == 33 ]]; then
    replace=$MODDIR/scripts/lmkd-a13
  elif [[ $sdk == 32 ]]; then
    replace=$MODDIR/scripts/lmkd-a12L
  elif [[ $sdk == 31 ]]; then
    replace=$MODDIR/scripts/lmkd-a12
  elif [[ $sdk == 30 ]]; then
    replace=$MODDIR/scripts/lmkd-a11
  fi
  if [[ "$replace" != '' ]]; then
    mkdir -p $(dirname $MODDIR/$lmkd)
    cp $replace $MODDIR/$lmkd
    # chcon u:object_r:lmkd_exec:s0 $replace
    # chown root:shell $replace
    # chmow -rwxr-xr-x $replace
    # mount --bind $replace $lmkd
  else
    rm $MODDIR/$lmkd
  fi
  # stop lmkd
  # start lmkd
}

replace_lmkd=$(get_prop replace_lmkd)
if [[ "$replace_lmkd" == 'true' ]]; then
  lmkd_override
else
  rm $MODDIR/$lmkd
fi

